package com.virtusa.trainingmanagementsystem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.trainingmanagementsystem.models.Nomination;


public interface NominationRepository extends JpaRepository<Nomination,Integer> {



}
